import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Loader2, BookOpen, Award, Download, Phone, Video, CheckCircle2, Zap, TrendingUp, Users, MessageSquare, Play } from "lucide-react";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { useEffect, useState } from "react";
import { toast } from "sonner";

const HERO_IMAGES = {
  module1: "https://d2xsxph8kpxj0f.cloudfront.net/310519663439371575/CMBBWtZvWAgrXyXEESAp4Y/module1-hero-9N7UUfKaFU6pyprgPGbuVH.webp",
  module2: "https://d2xsxph8kpxj0f.cloudfront.net/310519663439371575/CMBBWtZvWAgrXyXEESAp4Y/module2-hero-3B7Txv8Kwh6EdgQjzvjLbS.webp",
  module3: "https://d2xsxph8kpxj0f.cloudfront.net/310519663439371575/CMBBWtZvWAgrXyXEESAp4Y/module3-hero-9Ta5PzFu2LHdq4ZxNcDhGE.webp",
  module4: "https://d2xsxph8kpxj0f.cloudfront.net/310519663439371575/CMBBWtZvWAgrXyXEESAp4Y/module4-hero-kuDsxAyd3iZWTYGdFVMDaP.webp",
  module5: "https://d2xsxph8kpxj0f.cloudfront.net/310519663439371575/CMBBWtZvWAgrXyXEESAp4Y/module5-hero-Hn9gxgzQawCtYzVxMTHEgx.webp",
  module6: "https://d2xsxph8kpxj0f.cloudfront.net/310519663439371575/CMBBWtZvWAgrXyXEESAp4Y/module6-hero-WRuURFZzWTz2mXiEx73vp7.webp",
  module7: "https://d2xsxph8kpxj0f.cloudfront.net/310519663439371575/CMBBWtZvWAgrXyXEESAp4Y/module7-hero-TXznDE9oHeLymYTkHCZubs.webp",
  module8: "https://d2xsxph8kpxj0f.cloudfront.net/310519663439371575/CMBBWtZvWAgrXyXEESAp4Y/module8-hero-GL4dyt8KwbvnMZ4JPEJv6C.webp",
};

const MODULE_ICONS = [
  { icon: Zap, color: "text-orange-600" },
  { icon: BookOpen, color: "text-pink-600" },
  { icon: TrendingUp, color: "text-orange-600" },
  { icon: MessageSquare, color: "text-pink-600" },
  { icon: TrendingUp, color: "text-orange-600" },
  { icon: Zap, color: "text-pink-600" },
  { icon: Users, color: "text-orange-600" },
  { icon: MessageSquare, color: "text-pink-600" },
];

export default function Home() {
  const { user, loading, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const { data: modules } = trpc.course.getModules.useQuery();
  const { data: userProgress } = trpc.course.getUserProgress.useQuery(undefined, { enabled: !!user });
  const [completedCount, setCompletedCount] = useState(0);

  useEffect(() => {
    if (userProgress) {
      const completed = userProgress.filter((p) => p.completed).length;
      setCompletedCount(completed);
    }
  }, [userProgress]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-white via-white to-orange-50">
        <Loader2 className="w-8 h-8 animate-spin text-orange-600" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-white via-white to-orange-50">
        {/* Navigation */}
        <nav className="border-b border-orange-100 bg-white/80 backdrop-blur-sm sticky top-0 z-50">
          <div className="container flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-orange-600 to-pink-600"></div>
              <span className="font-display text-xl text-orange-600">Lemonade Bloom</span>
            </div>
            <Button onClick={() => (window.location.href = getLoginUrl())} className="bg-orange-600 hover:bg-orange-700 text-white">
              Sign In
            </Button>
          </div>
        </nav>

        {/* Hero Section */}
        <section className="py-20">
          <div className="container">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div className="animate-fade-in">
                  <h1 className="text-5xl md:text-6xl font-bold mb-6">
                  <span className="text-gradient">Master E-Commerce</span>
                </h1>
                <p className="text-xl text-gray-700 mb-2 leading-relaxed">
                  Learn how to build, scale, and dominate on Walmart Marketplace. From account setup to customer service excellence, we've got you covered.
                </p>
                <p className="text-lg text-orange-600 font-semibold mb-8">
                  Your Complete $299 Course Access
                </p>
                <div className="flex gap-4">
            <Button onClick={() => (window.location.href = getLoginUrl())} className="bg-orange-600 hover:bg-orange-700 text-white px-8 py-6 text-lg">
              Access Your Course
            </Button>
                  <Button variant="outline" className="border-orange-600 text-orange-600 hover:bg-orange-50 px-8 py-6 text-lg">
                    Learn More
                  </Button>
                </div>
                <div className="mt-12 grid grid-cols-3 gap-6">
                  <div>
                    <p className="text-3xl font-bold text-orange-600">8</p>
                    <p className="text-gray-600">Expert Modules</p>
                  </div>
                  <div>
                    <p className="text-3xl font-bold text-pink-600">24</p>
                    <p className="text-gray-600">Quiz Questions</p>
                  </div>
                  <div>
                    <p className="text-3xl font-bold text-orange-600">100%</p>
                    <p className="text-gray-600">Practical</p>
                  </div>
                </div>
              </div>
              <div className="animate-slide-in">
                <img 
                  src={HERO_IMAGES.module1} 
                  alt="Walmart Seller Setup" 
                  className="rounded-2xl shadow-2xl w-full"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-20 bg-white">
          <div className="container">
            <h2 className="text-4xl font-bold text-center mb-16 text-gradient">What You'll Learn</h2>
            <div className="grid md:grid-cols-4 gap-6">
              {[
                { title: "Account Setup", desc: "Get your Walmart seller account approved in days" },
                { title: "Product Research", desc: "Find winning products with proven criteria" },
                { title: "Shipping Mastery", desc: "Optimize shipping templates for profitability" },
                { title: "Order Management", desc: "Scale operations with efficient workflows" },
              ].map((feature, i) => (
                <Card key={i} className="p-6 hover:shadow-lg transition-shadow border-orange-100">
                  <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-orange-600 to-pink-600 flex items-center justify-center mb-4">
                    <span className="text-white font-bold text-lg">{i + 1}</span>
                  </div>
                  <h3 className="font-heading text-lg mb-2 text-orange-900">{feature.title}</h3>
                  <p className="text-gray-600 text-sm">{feature.desc}</p>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-gradient-to-r from-orange-600 to-pink-600">
          <div className="container text-center text-white">
            <h2 className="text-4xl font-bold text-center mb-6">Ready to Get Started?</h2>
            <p className="text-lg mb-8 opacity-90">Access your complete course and start building your Walmart empire today</p>
            <Button onClick={() => (window.location.href = getLoginUrl())} className="bg-white text-orange-600 hover:bg-gray-100 px-8 py-6 text-lg font-semibold">
              Access Your Course
            </Button>
          </div>
        </section>
      </div>
    );
  }

  const progressPercentage = modules ? (completedCount / modules.length) * 100 : 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-white via-white to-orange-50">
      {/* Header */}
      <div className="bg-white border-b border-orange-100 sticky top-0 z-40">
        <div className="container py-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold text-gradient mb-2">Welcome back, {user?.name?.split(' ')[0]}!</h1>
              <p className="text-gray-600">Continue your journey to e-commerce mastery</p>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-600 mb-2">Course Progress</p>
              <p className="text-2xl font-bold text-orange-600">{completedCount} / {modules?.length || 0}</p>
            </div>
          </div>
          <div className="space-y-2">
            <Progress value={progressPercentage} className="h-3" />
            <p className="text-sm text-gray-600">{Math.round(progressPercentage)}% Complete</p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container py-12">
        {/* Quick Actions */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          <Card className="p-6 hover:shadow-lg transition-all cursor-pointer group border-orange-100" onClick={() => setLocation("/booking/setup-call")}>
            <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-orange-600 to-pink-600 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <Phone className="w-6 h-6 text-white" />
            </div>
            <h3 className="font-heading text-lg mb-2 text-orange-900">Book Setup Call</h3>
            <p className="text-gray-600 text-sm mb-4">Get 1-on-1 guidance from our experts</p>
            <p className="font-bold text-orange-600">$499</p>
          </Card>

          <Card className="p-6 hover:shadow-lg transition-all cursor-pointer group border-pink-100" onClick={() => setLocation("/booking/webinar")}>
            <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-pink-600 to-orange-600 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <Play className="w-6 h-6 text-white" />
            </div>
            <h3 className="font-heading text-lg mb-2 text-pink-900">Join Webinar</h3>
            <p className="text-gray-600 text-sm mb-4">Live training with Q&A sessions</p>
            <p className="font-bold text-pink-600">$19.99</p>
          </Card>

          <Card className="p-6 hover:shadow-lg transition-all group border-orange-100">
            <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-orange-600 to-pink-600 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <BookOpen className="w-6 h-6 text-white" />
            </div>
            <h3 className="font-heading text-lg mb-2 text-orange-900">Download Workbook</h3>
            <p className="text-gray-600 text-sm mb-4">Comprehensive course materials</p>
            <a href="/api/download/workbook" className="text-orange-600 font-semibold text-sm hover:underline">
              Download PDF →
            </a>
          </Card>
        </div>

        {/* Modules Grid */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold mb-8 text-gradient">Course Modules</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {modules?.map((module, index) => {
              const isCompleted = userProgress?.some((p) => p.moduleId === module.id && p.completed);
              const IconComponent = MODULE_ICONS[index]?.icon || BookOpen;
              const heroImage = Object.values(HERO_IMAGES)[index];

              return (
                <Card 
                  key={module.id} 
                  className="module-card group cursor-pointer h-full flex flex-col border-orange-100 hover:border-orange-300 overflow-hidden"
                  onClick={() => setLocation(`/module/${module.id}`)}
                >
                  <div className="relative mb-4 overflow-hidden rounded-lg h-40">
                    <img 
                      src={heroImage} 
                      alt={module.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-black/20 group-hover:bg-black/30 transition-colors"></div>
                    {isCompleted && (
                      <div className="absolute top-2 right-2 bg-green-500 text-white rounded-full p-1">
                        <CheckCircle2 className="w-5 h-5" />
                      </div>
                    )}
                  </div>
                  <div className="flex-1 p-4">
                    <div className="flex items-start gap-3 mb-3">
                      <IconComponent className={`w-5 h-5 mt-1 flex-shrink-0 ${MODULE_ICONS[index]?.color}`} />
                      <h3 className="font-heading text-base leading-tight text-orange-900">{module.title}</h3>
                    </div>
                    <p className="text-sm text-gray-600 mb-4">{module.description}</p>
                  </div>
                  <div className="flex items-center justify-between p-4 border-t border-orange-100">
                    <span className="text-xs font-semibold text-orange-600">Module {index + 1}</span>
                    {isCompleted ? (
                      <span className="text-xs font-semibold text-green-600">✓ Completed</span>
                    ) : (
                      <span className="text-xs font-semibold text-gray-500">Start →</span>
                    )}
                  </div>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Completion Bonus */}
        {completedCount === modules?.length && modules?.length > 0 && (
          <Card className="p-8 bg-gradient-to-r from-orange-50 to-pink-50 border-2 border-orange-200">
            <div className="flex items-center gap-4 mb-4">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-orange-600 to-pink-600 flex items-center justify-center">
                <CheckCircle2 className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gradient">Congratulations!</h3>
            </div>
            <p className="text-gray-700 mb-6">You've completed all 8 modules! Download your free welcome guide and continue your journey.</p>
            <Button className="bg-gradient-to-r from-orange-600 to-pink-600 hover:from-orange-700 hover:to-pink-700 text-white">
              <Download className="w-4 h-4 mr-2" />
              Download Free Welcome Guide
            </Button>
          </Card>
        )}
      </div>
    </div>
  );
}
