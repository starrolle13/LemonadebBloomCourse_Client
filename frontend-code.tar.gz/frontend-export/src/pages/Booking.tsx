import { useParams, useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, Phone, Video, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";

export default function Booking() {
  const params = useParams();
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const bookingType = params.type as "setup-call" | "webinar";

  const [email, setEmail] = useState(user?.email || "");
  const [name, setName] = useState(user?.name || "");

  const createSetupCallMutation = trpc.payment.createSetupCallCheckout.useMutation();
  const createWebinarMutation = trpc.payment.createWebinarCheckout.useMutation();

  const isSetupCall = bookingType === "setup-call";
  const title = isSetupCall ? "1-on-1 Setup Call" : "Live Webinar";
  const description = isSetupCall
    ? "Get personalized guidance through setup questions from an expert"
    : "Join our live webinar to learn advanced strategies";
  const price = isSetupCall ? "$499" : "$19.99";
  const icon = isSetupCall ? Phone : Video;
  const Icon = icon;

  const handleBooking = async () => {
    if (!email || !name) {
      toast.error("Please fill in all fields");
      return;
    }

    try {
      const mutation = isSetupCall ? createSetupCallMutation : createWebinarMutation;
      const result = await mutation.mutateAsync({ email, name });

      if (result.checkoutUrl) {
        window.open(result.checkoutUrl, "_blank");
        toast.success("Redirecting to payment...");
      }
    } catch (error) {
      toast.error("Failed to create booking");
    }
  };

  const isLoading = createSetupCallMutation.isPending || createWebinarMutation.isPending;

  return (
    <div className="min-h-screen bg-gradient-to-br from-accent via-background to-light-accent">
      {/* Header */}
      <div className="bg-white border-b border-border">
        <div className="container py-6">
          <Button variant="ghost" onClick={() => setLocation("/")} className="text-muted-foreground hover:text-foreground mb-4">
            ← Back to Dashboard
          </Button>
          <h1 className="text-4xl font-display text-primary">Complete Your Booking</h1>
        </div>
      </div>

      {/* Main Content */}
      <div className="container py-8">
        <div className="max-w-2xl mx-auto">
          <Card className="bg-white border-border shadow-lg">
            <CardHeader>
              <div className="flex items-center gap-3 mb-4">
                <div className="p-3 bg-primary/10 rounded-lg">
                  <Icon className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <CardTitle className="text-2xl text-primary">{title}</CardTitle>
                  <CardDescription>{description}</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Booking Details */}
              <div className="bg-accent/50 p-4 rounded-lg space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-foreground font-medium">Booking Type:</span>
                  <span className="text-primary font-heading">{title}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-foreground font-medium">Price:</span>
                  <span className="text-2xl font-bold text-primary">{price}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-foreground font-medium">Payment Method:</span>
                  <span className="text-muted-foreground">Credit Card (Stripe)</span>
                </div>
              </div>

              {/* Form */}
              <div className="space-y-4">
                <div>
                  <Label htmlFor="name" className="text-foreground font-medium">
                    Full Name
                  </Label>
                  <Input
                    id="name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Your full name"
                    className="mt-1 border-border"
                  />
                </div>

                <div>
                  <Label htmlFor="email" className="text-foreground font-medium">
                    Email Address
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="your@email.com"
                    className="mt-1 border-border"
                  />
                </div>
              </div>

              {/* Benefits */}
              <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                <h3 className="font-heading text-green-900 mb-3">What You'll Get:</h3>
                <ul className="space-y-2 text-sm text-green-800">
                  {isSetupCall ? (
                    <>
                      <li className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4" />
                        60-minute personalized consultation
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4" />
                        Custom setup strategy for your business
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4" />
                        Direct access to expert guidance
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4" />
                        Follow-up resources and templates
                      </li>
                    </>
                  ) : (
                    <>
                      <li className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4" />
                        Live interactive training session
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4" />
                        Advanced strategies and tactics
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4" />
                        Q&A with the instructor
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4" />
                        Lifetime access to recording
                      </li>
                    </>
                  )}
                </ul>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-4 pt-6 border-t border-border">
                <Button variant="outline" onClick={() => setLocation("/")} className="flex-1 border-primary text-primary hover:bg-accent">
                  Cancel
                </Button>
                <Button onClick={handleBooking} disabled={isLoading} className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground">
                  {isLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    <>
                      Proceed to Payment
                      <Icon className="w-4 h-4 ml-2" />
                    </>
                  )}
                </Button>
              </div>

              {/* Security Note */}
              <p className="text-xs text-muted-foreground text-center">
                Your payment information is secure and encrypted. We use Stripe for all transactions.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
