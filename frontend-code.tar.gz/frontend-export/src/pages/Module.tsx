import { useParams, useLocation } from "wouter";
import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Loader2, ChevronRight, ChevronLeft, CheckCircle2, Download } from "lucide-react";
import { toast } from "sonner";
import { COURSE_WORKBOOK_URL } from "@shared/courseData";
import { enrichedModuleContent } from "@shared/enrichedContent";

export default function Module() {
  const params = useParams();
  const [, setLocation] = useLocation();
  const moduleId = parseInt(params.id || "1", 10);
  const [currentStep, setCurrentStep] = useState(0);
  const [showQuiz, setShowQuiz] = useState(false);
  const [quizAnswers, setQuizAnswers] = useState<number[]>([]);

  const { data: module, isLoading: moduleLoading } = trpc.course.getModule.useQuery({ moduleId });
  const { data: quizzes } = trpc.course.getQuizzes.useQuery({ moduleId });
  const { data: progress } = trpc.course.getModuleProgress.useQuery({ moduleId });
  const { data: latestAttempt } = trpc.course.getLatestQuizAttempt.useQuery({ moduleId });

  const completeModuleMutation = trpc.course.completeModule.useMutation();
  const submitQuizMutation = trpc.course.submitQuiz.useMutation();

  const enrichedContent = enrichedModuleContent[moduleId as keyof typeof enrichedModuleContent];
  const steps = (module?.content as any) || [];
  const currentStepData = steps[currentStep];
  const isLastStep = currentStep === steps.length - 1;

  const handleNextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      setShowQuiz(true);
    }
  };

  const handlePreviousStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleQuizAnswer = (questionIndex: number, answerIndex: number) => {
    const newAnswers = [...quizAnswers];
    newAnswers[questionIndex] = answerIndex;
    setQuizAnswers(newAnswers);
  };

  const handleSubmitQuiz = async () => {
    if (!quizzes) return;

    let score = 0;
    quizzes.forEach((quiz, index) => {
      if (quizAnswers[index] === quiz.correctAnswer) {
        score++;
      }
    });

    const percentage = Math.round((score / quizzes.length) * 100);

    try {
      await submitQuizMutation.mutateAsync({
        moduleId,
        score,
        totalQuestions: quizzes.length,
        answers: quizAnswers,
      });

      await completeModuleMutation.mutateAsync({ moduleId });

      toast.success(`Quiz Complete! You scored ${percentage}%`);
      setTimeout(() => setLocation("/"), 2000);
    } catch (error) {
      toast.error("Failed to submit quiz");
    }
  };

  if (moduleLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!module) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-heading mb-4">Module not found</h1>
          <Button onClick={() => setLocation("/")}>Back to Dashboard</Button>
        </div>
      </div>
    );
  }

  const progressPercentage = ((currentStep + 1) / (steps.length + 1)) * 100;

  return (
    <div className="min-h-screen bg-gradient-to-br from-accent via-background to-light-accent">
      {/* Header */}
      <div className="bg-white border-b border-border sticky top-0 z-10">
        <div className="container py-4">
          <div className="flex items-center justify-between mb-4">
            <Button variant="ghost" onClick={() => setLocation("/")} className="text-muted-foreground hover:text-foreground">
              ← Back to Modules
            </Button>
            <Button variant="outline" size="sm" onClick={() => window.open(COURSE_WORKBOOK_URL, "_blank")} className="border-primary text-primary">
              <Download className="w-4 h-4 mr-2" />
              Workbook
            </Button>
          </div>
          <div>
            <h1 className="text-3xl font-display text-primary">{module.title}</h1>
            <p className="text-muted-foreground">{module.description}</p>
          </div>
          <div className="mt-4 space-y-2">
            <div className="flex justify-between text-sm">
              <span className="font-medium text-foreground">
                {showQuiz ? "Quiz" : `Step ${currentStep + 1} of ${steps.length}`}
              </span>
              <span className="text-muted-foreground">{Math.round(progressPercentage)}%</span>
            </div>
            <Progress value={progressPercentage} className="h-2" />
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container py-8">
        {!showQuiz ? (
          // Step Content
          <div className="max-w-3xl mx-auto">
            <Card className="bg-white border-border shadow-lg">
              <CardHeader>
                <CardTitle className="text-2xl text-primary">{module.title}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {enrichedContent?.content ? (
                  <div className="prose prose-sm max-w-none text-foreground leading-relaxed whitespace-pre-wrap">
                    {enrichedContent.content}
                  </div>
                ) : (
                  <p className="text-lg text-foreground leading-relaxed">{currentStepData?.content}</p>
                )}

                {/* Navigation */}
                <div className="flex gap-4 pt-6 border-t border-border">
                  <Button
                    variant="outline"
                    onClick={handlePreviousStep}
                    disabled={currentStep === 0}
                    className="flex-1 border-primary text-primary hover:bg-accent disabled:opacity-50"
                  >
                    <ChevronLeft className="w-4 h-4 mr-2" />
                    Previous
                  </Button>
                  <Button
                    onClick={handleNextStep}
                    className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground"
                  >
                    {isLastStep ? (
                      <>
                        Start Quiz
                        <ChevronRight className="w-4 h-4 ml-2" />
                      </>
                    ) : (
                      <>
                        Next
                        <ChevronRight className="w-4 h-4 ml-2" />
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        ) : (
          // Quiz Content
          <div className="max-w-3xl mx-auto">
            <Card className="bg-white border-border shadow-lg">
              <CardHeader>
                <CardTitle className="text-2xl text-primary">Module Quiz</CardTitle>
                <CardDescription>Answer all questions to complete this module</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {quizzes?.map((quiz, index) => (
                  <div key={index} className="pb-6 border-b border-border last:border-b-0">
                    <h3 className="font-heading text-lg text-foreground mb-4">
                      {index + 1}. {quiz.question}
                    </h3>
                    <div className="space-y-3">
                      {(quiz.options as string[]).map((option, optionIndex) => (
                        <label
                          key={optionIndex}
                          className="flex items-center gap-3 p-3 border border-border rounded-lg cursor-pointer hover:bg-accent transition-colors"
                        >
                          <input
                            type="radio"
                            name={`question-${index}`}
                            value={optionIndex}
                            checked={quizAnswers[index] === optionIndex}
                            onChange={() => handleQuizAnswer(index, optionIndex)}
                            className="w-4 h-4"
                          />
                          <span className="text-foreground">{option}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                ))}

                {/* Submit Button */}
                <div className="flex gap-4 pt-6">
                  <Button
                    variant="outline"
                    onClick={() => setShowQuiz(false)}
                    className="flex-1 border-primary text-primary hover:bg-accent"
                  >
                    Back to Content
                  </Button>
                  <Button
                    onClick={handleSubmitQuiz}
                    disabled={quizAnswers.length < (quizzes?.length || 0) || submitQuizMutation.isPending}
                    className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground disabled:opacity-50"
                  >
                    {submitQuizMutation.isPending ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Submitting...
                      </>
                    ) : (
                      <>
                        <CheckCircle2 className="w-4 h-4 mr-2" />
                        Submit Quiz
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
